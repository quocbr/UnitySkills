# Protocol: Error Codes

## Read the body, not the status code

The HTTP status tells you whether the *request* was accepted, not whether the *skill* succeeded:

| Layer | Status | Body |
|---|---|---|
| Skill-level failure (bad target, bad value, refused write) | `200` | `status: "error"` + `errorCode` |
| Batch with some failed steps | `200` | `status: "partial"` (or `"rolled_back"` in transactional mode), per-step `status` in `results[]` |
| Endpoint-level failure (malformed body, unknown mode, >50 batch steps, oversized body) | `4xx` | `errorCode` for the request itself |
| Transport / transient (`COMPILING`, `RATE_LIMIT`, `QUEUE_FULL`, `SERVER_STOPPED`, `TIMEOUT`) | `429` / `503` / `504` | `errorCode` + `retryAfterSeconds` |

So a client that branches on `response.status_code == 200` will read a failed skill call as a success. Always parse the body and check `status` / `errorCode`. The two authorization outcomes (`MODE_RESTRICTED`, `MODE_FORBIDDEN`), `SURFACE_EXCLUDED` and `DRYRUN_REQUIRED` are also HTTP `200` — they are decisions, not transport faults.

Every error response carries a top-level `errorCode` (plus `retryStrategy` / `retryAfterSeconds` when applicable — see `SkillErrorResponse.Build` in the server source). **The Python client (`unity_skills.py`) already auto-retries `COMPILING` / `RATE_LIMIT` / `QUEUE_FULL` / `SERVER_STOPPED`** using the server's own `retryAfterSeconds` — if you're calling through `unity_skills.call_skill(...)` you normally never see these codes at all; the table below is for building a custom client or interpreting a final failure after retries are exhausted. It never resends a write whose outcome is unknown (a `504`, a timeout, a connection dropped after sending): that result carries `requestOutcomeUnknown: true`.

## Transport / transient errors

| `errorCode` | HTTP | Meaning | Action |
|---|---|---|---|
| `COMPILING` | 503 | Unity is compiling or mid-Domain-Reload — expected right after script/define/package edits. Nothing ran (with `details.executed:false` when a reload began while the request was queued) | Wait `retryAfterSeconds` (5s, 8s if a reload is pending) and retry, writes included. Auto-retried by the Python client |
| `RATE_LIMIT` | 429 | Too many requests/sec against the admission limiter | Wait `retryAfterSeconds` (1s) and retry. Auto-retried by the Python client |
| `QUEUE_FULL` | 503 | Too many requests already pending on the main-thread queue | Wait `retryAfterSeconds` (2s) and retry. Auto-retried by the Python client |
| `SERVER_STOPPED` | 503 | Server is stopping (manual stop, Editor quit, watchdog restart); the request never ran (`details.executed:false`) | Wait `retryAfterSeconds` (5s) for it to come back and retry, writes included. Auto-retried by the Python client |
| `TIMEOUT` | 504 | Main thread didn't respond within the request timeout. Outcome unknown: the request may still run, or may have run | A read: wait (5s if a Domain Reload is pending, else 10s) and retry. A write: do not resend it blindly — check its job (`GET /jobs`) or the state it changes first. If it persists, check for a stuck modal dialog or long-running operation in the Editor |
| `BODY_TOO_LARGE` | 413 | POST body exceeded the server's max size | Not retryable as-is — shrink the request (e.g. split a large `/skills/batch` into smaller batches) |
| `MODE_RESTRICTED` | 200 (`status:"error"` in the body) | Approval mode: the skill is `FullAuto` and needs a user grant | Follow the Approval Mode Grant Protocol — do not retry the raw call |
| `MODE_FORBIDDEN` | 200 (`status:"error"` in the body) | Skill is auto-classified `NeverInSemi` (`approvalBehavior: "forbid"`: Delete/PlayMode/Reload/high-risk) and the current mode (Auto or Approval) isn't Bypass | Only the user can lift it, and `details.hint` says so: tell them it needs Bypass mode or an Allowlist entry — do not attempt the grant flow |
| `DRYRUN_REQUIRED` | 200 (`status:"error"` in the body) | The user's `dryRunPolicy` (`highRisk` / `allWrites`) gates this write and the call carried no usable `?dryRunToken=`. Nothing ran | Read `details.dryRun` (the preview), then resend the same body with `?dryRunToken=<details.dryRunToken>`; `suggestedFixes[0]` is that exact call. The token is single use for 300 s; `details.reason` says why the presented one was refused. See [operating mode](protocol-operating-mode.md) |
| `SURFACE_EXCLUDED` | 200 (`status:"error"` in the body) | The current `surfaceProfile` hides this skill — either because it is a write in a hidden category, or by name for a master key like `editor_execute_menu`. Not a permission problem: the user took the operation off the menu, so no mode — Bypass included — and no Allowlist entry can run it | Follow `details.hint`. When `details.manualDoc` is set (`guide` profile), read that document and instruct the user through the Editor steps; when it is null — a name-hidden skill, or any `noSceneAuthoring` exclusion — name the menu path yourself or tell the user the step needs the profile back on `full`. Do not retry, and do not reach for another module that does the same write |

> **Two response shapes carry this code.** A name-hidden or category-hidden skill's rejection nests `manualDoc`/`hint` under `details`, like any other skill error. A *carried-write* rejection — `batch_execute` / `batch_retry_failed` acting on a `confirmToken`'s payload, or `workflow_undo_task` / `workflow_redo_task` / `workflow_revert_task` / `workflow_session_undo` restoring a snapshot — instead puts `surfaceProfile` / `category` / `operation` / `manualDoc` / `userControlled` / `hint` at the response's **top level**, because the router's skill-error pass-through forwards a skill's unrecognised members verbatim but drops a skill-authored `details` object; nesting them there would silently lose them.

## Domain reload and server stop

When a reload begins (script, define or package change, entering Play Mode) or the server stops, it first answers every request it still holds, then closes the port until it is back:

- `503` — `COMPILING` during a reload, `SERVER_STOPPED` on a stop — with `details.executed:false`: the request never ran, so resending it is safe, writes included. A request arriving while the server drains gets the same answer.
- `504`: the request may have run. Retry a read; for a write, check its outcome (its job, or the state it changes) instead of resending it.
- Every `429` / `503` also carries a `Retry-After` header equal to `retryAfterSeconds`.
- A connection the reload closed before an answer was written ends with a bare status line and no body: `503` + `Retry-After` if the request never started, `504` if a write had started. An empty `200`, or a connection closed with no answer at all, means no answer was ever written (the request reached the port in the instant the listener closed, or went out on an idle connection the server had just closed): treat it like a `504`.

## Request errors (4xx)

The request itself was malformed, so nothing was routed to a skill. The body still carries `errorCode`, `retryStrategy` and a `details` object that names the offending part.

| `errorCode` | HTTP | Meaning | Action |
|---|---|---|---|
| `UNKNOWN_PARAM` | 400 | A `GET /skills` or `GET /skills/schema` query used a skill-selector-like key that the filter grammar does not have — `skill`, `skills`, `name`, `skillname`, `skill_name`, `id`, `ids` (`details.parameter` / `details.value`). Any other unrecognised key is still ignored silently, so this is the one case where a typo does not fall back to the unfiltered listing | Use `names=<exact,comma,list>` for specific skills or `q=<fragment>` to search; `details.validKeys` lists every accepted filter key and `details.example` is a ready-to-send URL. `retryStrategy` is `fix_and_retry` |
| `INSTANCE_MISMATCH` | 409 | The request named the Editor it is meant for — `expectInstance` (exact instanceId) or `expectProject` (productName or project folder name), as a query parameter or an `X-Expect-Instance` / `X-Expect-Project` header — and this server is another one. Checked before anything is queued, so nothing ran. `/health` is never checked | Resend to the instance a `suggestedFixes` entry names (`args.port`, `args.url`). `details.server` says who answered; `details.instances` lists the other registered Editors with `port` and `status` — wait for a `reloading` one rather than switching. `retryStrategy` is `fix_and_retry`. The Python client sends `X-Expect-Instance` itself when it resolved the instance from the working directory or `target`, and follows that instance to a new port |
| `METHOD_NOT_ALLOWED` | 405 | `GET /skill/<name>` on a registered skill: skills only run on `POST` (an unregistered name still answers `NOT_FOUND`). Nothing ran | Resend `details.curl` (`details.powershell` is the same call for PowerShell) — the same call as `POST` with the query arguments moved into the JSON body and request-level keys (`mode`, `dryRun`, `diff`, `wire`, `expect*`) kept in the URL. `details.body` (also `suggestedFixes[0].args`) is the converted body |
| `INVALID_MODE` | 400 | A mode flag held a value the server does not know, so a typo cannot fall through to a real run: `?mode=` other than `dryRun` / `plan` (`/skills/batch` also takes `transactional`), `?dryRun=` other than `true` / `false`, or `?diff=` other than `1` / `true` / `0` / `false`. `details.received` and `details.validValues` name the value and the accepted ones. Nothing ran | Resend with a value from `details.validValues`, or omit the flag to execute for real |

## Business errors

A skill ran but refused the request. All of these come back as HTTP `200` with `status:"error"` in the body, and carry `retryStrategy` plus `suggestedFixes`/`relatedSkills` naming the skill to call next. None is auto-retried by the Python client: they need a corrected call, not a wait.

| `errorCode` | `retryStrategy` | Meaning | Action |
|---|---|---|---|
| `TARGET_NOT_FOUND` | `find_target_and_retry` | The GameObject / asset / component the skill was pointed at does not exist. Also carries `instance` (`<project>@<port>`); a different editor than intended means the call went to the wrong one | Locate it first (`gameobject_find`, `scene_get_hierarchy`, `asset_find`, `component_list` — `relatedSkills` says which), then retry with the `entityId` or exact path it returns |
| `MISSING_PACKAGE` | `install_and_retry` | The skill's optional package (ProBuilder / XR / Netcode / DOTween / YooAsset / URP …) is not installed | Tell the user which package is missing (the message names the package id); installing it with `package_install` is their call, then wait out the Domain Reload and retry. `suggestedFixes[0]` is `ask_user` for this reason; the `package_install` fix after it is for when the user agrees. A dryRun (`validation.missingPackages`) and recommend (`unavailable`) report the same before any call, so no extra probe is needed |
| `MISSING_PARAM` | `fix_and_retry` | A required parameter was omitted | Add the parameter named in the message. A call rejected by validation ran nothing, and its `details` already carries every validation bucket plus the parameter list (the report a dryRun would give), so fix and retry directly |
| `SEMANTIC_INVALID` | `fix_and_retry` | A parameter was supplied but rejected — out of range, unknown enum value, wrong asset type, or the target already exists | Read the accepted range/values from the message and `details.validation`, correct the args, retry |
| `WORKFLOW_CONFLICT` | `fix_and_retry` | A workflow restore (`workflow_restore`, `workflow_undo_task`, `workflow_redo_task`, `workflow_session_undo`) would overwrite changes made since the checkpoint or step: by the user in the editor, or by another agent. Nothing ran: no guard was taken. The response's top-level `conflicts` lists each one (`id`, `target`, `by`, `what`, `at`, and `confidence:"logged"` for journal entries) and `coverage` says how far the journal reached (`full`, `partial`, `unknown`) | Ask the user, default to keeping their changes. Then retry the same call with `conflicts:"keep"` (skip every conflicting target), or with the comma-separated ids to overwrite. Targets with a conflict that is not listed are kept and named in the response's `skippedItems` |

> **Rejected enum values are self-describing.** A bad value for an enum-shaped parameter (`shadows`, `clearFlags`, `lightType`, `flags`, …) returns `SEMANTIC_INVALID` with `parameter` naming the offending argument and **`validValues` listing every accepted member** — take the list from there instead of guessing or re-fetching the schema. Matching is case-insensitive **and interior spaces are stripped first**, so an Inspector label pastes in verbatim (`"Normal Map"` → `NormalMap`, `"Low Quality"` → `CompressedLQ`). Some enums also carry an alias table mapping the Inspector's wording onto the CLR member name, and `validValues` lists both spellings — so if the label and the CLR name differ, either one is accepted.
>
> One case is *not* "genuinely unknown" yet still rejected: a **deprecated member that owns a numeric value no live member claims** — Unity's removed texture types (`Image`, `Bump`, `Cubemap`, `Reflection`, `Advanced`, `HDRI`) are refused rather than silently written. The filter is by value, not by name, so a deprecated *spelling* that shares its value with a live member keeps working: `LightType.Area` still resolves (it is the same value as `Rectangle`), as does `TextureImporterFormat.AutomaticCompressed` (same value as `Automatic`). Do not read "deprecated" as "rejected" — check `validValues`. Such a rejection applies **nothing**: sibling parameters in the same call are not written, so a retry with the value corrected is safe and non-cumulative. The same payload shape (plus `target`) is used per item inside a `*_batch` call.
| `SKILL_ERROR` | `abort` | A genuine runtime failure inside the skill (I/O error, reflection failure, unusable editor state) | Do not retry blind — report the message to the user or pick another approach |

> These codes are derived at the routing layer, so they apply across all skills, including ones whose own error text is a bare sentence. A skill may also declare `errorCode` / `retryStrategy` / `suggestedFixes` / `relatedSkills` on its error object, in which case those are passed through verbatim and override the derivation.
